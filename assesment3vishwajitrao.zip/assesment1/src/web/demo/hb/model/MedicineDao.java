package web.demo.hb.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class MedicineDao {

	private static StandardServiceRegistry registry;
	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
		}
		return sessionFactory;
	}

	public static void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}
	
	
	public void create(Medicine m) {
		try(Session session = getSessionFactory().openSession()){
			
			session.getTransaction().begin();
			session.save(m);
			session.getTransaction().commit();
		}
	}
	

	public Medicine findOne(String id) {
		Medicine m = null;
		try(Session session = getSessionFactory().openSession()){
			m = session.get(Medicine.class, id);
		}
		return m;
	}
	
	public List<Medicine> findAll(){
		String query = "from Medicine m";
		List<Medicine> medicines = null;
		try(Session session = getSessionFactory().openSession()){
			medicines = session.createQuery(query, Medicine.class).getResultList();
		}
		return medicines;
	}

}
