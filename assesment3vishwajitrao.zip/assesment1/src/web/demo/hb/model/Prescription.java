package web.demo.hb.model;

import java.util.Arrays;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "web_prescription")
public class Prescription {

	@Id
	private int id;
	private Date date;

	private String[] MedicineList;

	
	public Prescription() {

	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public String[] getMedicineList() {
		return MedicineList;
	}


	public void setMedicineList(String[] medicineList) {
		MedicineList = medicineList;
	}


	public Prescription(int id, Date date, String[] medicineList) {
		super();
		this.id = id;
		this.date = date;
		MedicineList = medicineList;
	}


	@Override
	public String toString() {
		return "Prescription [id=" + id + ", date=" + date + ", MedicineList=" + Arrays.toString(MedicineList) + "]";
	}
	
	
	
}
