package web.demo.hb.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class PrescriptionDao {

	private static StandardServiceRegistry registry;
	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
		}
		return sessionFactory;
	}

	public static void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}
	
	
	public void create(Prescription pr) {
		try(Session session = getSessionFactory().openSession()){
			
			session.getTransaction().begin();
			session.save(pr);
			session.getTransaction().commit();
		}
	}
	

	public Prescription findOne(String id) {
		Prescription pr = null;
		try(Session session = getSessionFactory().openSession()){
			pr = session.get(Prescription.class, id);
		}
		return pr;
	}
	
	public List<Prescription> findAll(){
		String query = "from Prescription pr";
		List<Prescription> prescriptions = null;
		try(Session session = getSessionFactory().openSession()){
			prescriptions = session.createQuery(query, Prescription.class).getResultList();
		}
		return prescriptions;
	}

}
