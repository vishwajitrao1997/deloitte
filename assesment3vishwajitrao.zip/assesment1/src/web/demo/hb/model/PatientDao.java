package web.demo.hb.model;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class PatientDao {

	private static StandardServiceRegistry registry;
	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			registry = new StandardServiceRegistryBuilder().configure().build();
			MetadataSources sources = new MetadataSources(registry);
			Metadata metadata = sources.getMetadataBuilder().build();
			sessionFactory = metadata.getSessionFactoryBuilder().build();
		}
		return sessionFactory;
	}

	public static void shutdown() {
		if (registry != null) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
	}
	
	
	public void create(Patient p) {
		try(Session session = getSessionFactory().openSession()){
			
			session.getTransaction().begin();
			session.save(p);
			session.getTransaction().commit();
		}
	}
	

	
	public Patient findOne(String id) {
		Patient p = null;
		try(Session session = getSessionFactory().openSession()){
			p = session.get(Patient.class, id);
		}
		return p;
	}
	
	public List<Patient> findAll(){
		String query = "from Patient p";
		List<Patient> patients = null;
		try(Session session = getSessionFactory().openSession()){
			patients = session.createQuery(query, Patient.class).getResultList();
		}
		return patients;
	}

}
