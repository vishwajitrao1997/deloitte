package web.demo.hb.model;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "web_medicines")
public class Medicine {

	@Id
	private int id;
	
	private String name;

	


	
	public Medicine() {
}





	public int getId() {
		return id;
	}





	public void setId(int id) {
		this.id = id;
	}





	public String getName() {
		return name;
	}





	public void setName(String name) {
		this.name = name;
	}





	@Override
	public String toString() {
		return "Medicine [id=" + id + ", name=" + name + "]";
	}





	public Medicine(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	
}