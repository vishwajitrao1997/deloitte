package web.demo.hb.servlets;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import web.demo.hb.model.PatientDao;
import web.demo.hb.model.Patient;

/**
 * Servlet implementation class CreateServlet
 */
@WebServlet("/createServlet")
public class CreateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id=Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name").trim();
		String email = request.getParameter("email").trim();
		Date date = null;
		try {
			date = new SimpleDateFormat("dd/MM/yyyy").parse("date");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Patient p = new Patient(id,name,email,date);
		PatientDao dao = new PatientDao();
		dao.create(p);
		List<Patient> patients = dao.findAll();
		
		request.setAttribute("patients", patients);
		request.getRequestDispatcher("index.jsp").forward(request, response);
		
	}

}
